# pyVideoServer

TODO PHASE1:

1. pyv restart_server
1. pyv test_performance
1. pyv watch 0
1. pyv assign
1. pyv watch front
1. pyv record ./record/

TODO PHASE2:

1. integrate into svr

TODO PHASE3:

1. pyv list